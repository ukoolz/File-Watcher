/*
Name       : Dibyendu Das
Roll       : 14CS60R34
Assignment : 3
Part       : 3
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <linux/inotify.h>
#include <sys/stat.h>
#include <ftw.h>

#define EVENT_SIZE     sizeof(struct inotify_event)
#define EVENT_BUF_LEN  (1024 * (EVENT_SIZE + 16))
#define NO_OF_WATCH_DESCRIPTORS  1000
#define BUFFER_SIZE 400

#define DEBUG

FILE *fp = NULL;
struct FTW;
int notify_fd;
char *wd[NO_OF_WATCH_DESCRIPTORS] = {NULL};

void execute_command(char *command, char *options, char *argument, bool read_input_from_stdin, char *buffer) {
  int nbytes, from_child[2], to_child[2], arg_index = 0;
  char *args[20] = {NULL}, *token;
  args[arg_index++] = command;
  token = strtok(options, " ");
  while(token) {
    args[arg_index] = (char *) malloc(strlen(token) + 1);
    strcpy(args[arg_index++], token);
    token = strtok(NULL, " ");
  }
  token = strtok(argument, " ");
  while(token) {
    args[arg_index] = (char *) malloc(strlen(token) + 1);
    strcpy(args[arg_index++], token);
    token = strtok(NULL, " ");
  }

  pipe(to_child);
  pipe(from_child);

  if(!fork()) {
      close(to_child[1]);              // Close the write descriptor of the pipe to_child
      close(from_child[0]);            // Close the read descriptor of the pipe from_child
      /*
      Leave the STDIN open if the flag read_input_from_stdin is set.
      Redirect everything that comes to the pipe to_child[0] (read descriptor) to STDIN otherwise.
      */
      if(!read_input_from_stdin) {
        close(0);
        dup(to_child[0]);
      }
      close(1);                        // Close the file descriptor STDOUT
      dup(from_child[1]);              // Redirect STDOUT to the write descriptor of the from_child pipe & send output to the parent
      execvp(args[0], args);
    } else {
      close(to_child[0]);              // Close the read descriptor of the pipe to_child
      close(from_child[1]);            // Close the write descriptor of the pipe from_child
      if(!read_input_from_stdin) {
        nbytes = write(to_child[1], buffer, strlen(buffer));
        close(to_child[1]);
        #ifdef DEBUG
        printf("==== parent wrote %d bytes of following data to child ====\n%s\
==========================================================\n", nbytes, buffer);
        #endif /* DEBUG */
      }
      nbytes = read(from_child[0], buffer, BUFFER_SIZE);
      buffer[nbytes] = '\0';
      #ifdef DEBUG
      printf("==== child executed '%s' & returned %d bytes of following data to parent ====\n%s\
=============================================================================\n", command, nbytes, buffer);
      #endif /* DEBUG */
      wait(NULL);
    }
  return;
}

void main_sigint(int signum) {
  printf("\nExiting the watcher ...\n");
  if(fp)
    fclose(fp);
  exit(0);
}

int add_watch(char *wd[], int fd, char *path) {
  int i = inotify_add_watch(fd, path, IN_ALL_EVENTS);
  wd[i] = (char *) calloc(strlen(path) + 1, 1);
  strcpy(wd[i], path);
  #ifdef DEBUG
  printf("[DEBUG]\tAdded watch descriptor %d on path %s\n", i, wd[i]);
  #endif
  return i;
}

void remove_watch(char *wd[], int notify_fd, int whatch_fd) {
  inotify_rm_watch(notify_fd, whatch_fd);
  #ifdef DEBUG
  printf("[DEBUG]\tRemoved watch descriptor %d on path %s\n", whatch_fd, wd[whatch_fd]);
  #endif
  if(wd[whatch_fd]) {
    free(wd[whatch_fd]);
    wd[whatch_fd] = NULL;
  }
  return;
}

int callback(char *file_path, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
  struct stat statbuf;
  stat(file_path, &statbuf);
  if(S_ISDIR(statbuf.st_mode))
    add_watch(wd, notify_fd, file_path);
  return 0;
}

void remove_duplicate() {
  char options[100], arg[200], file_a[200], file_b[200], *buffer = (char *) calloc(BUFFER_SIZE, 1);;
  struct stat st_a, st_b;

  strcpy(options, "-srq");
  strcpy(arg, "./DummyHome/DummyDloads ./DummyHome/DummyDManager");
  execute_command("diff", options, arg, true, buffer);
  strcpy(options, "");
  strcpy(arg, "identical");
  execute_command("grep", options, arg, false, buffer);
  while(sscanf(buffer, "Files %s and %s are identical%*c", file_a, file_b) != EOF) {
    #ifdef DEBUG
    printf("[DEBUG] Duplicate files '%s' & '%s'\n", file_a, file_b);
    #endif
    stat(file_a, &st_a);
    stat(file_b, &st_b);
    if((long)st_a.st_mtime - (long)st_b.st_mtime > 0)
      remove(file_b);
    else if((long)st_a.st_mtime - (long)st_b.st_mtime < 0)
      remove(file_a);
    buffer = buffer + 26 + strlen(file_a) + strlen(file_b);
  }
  return;
}

void copy_from_temp(char *file, char *dir) {
  char temp[1024], command[1024];
  struct stat st;
  int a, m, c;

  if(!strstr(dir, "./DummyHome/DummyTemp"))
    return;
  strcpy(temp, dir);
  strcat(strcat(temp, "/"), file);
  stat(temp, &st);
  a = (long) st.st_atime;
  m = (long) st.st_mtime;
  c = (long) st.st_ctime;
  if(abs(a - m) < 120 || abs(a - c) < 60 || abs(m - c) < 30) {
    #ifdef DEBUG
    printf("[DEBUG] Copying file '%s' to './DummyHome/DummyDloads'\n", temp);
    #endif
    strcpy(command, "cp -f ");
    strcat(strcat(strcat(command, temp), " "), "./DummyHome/DummyDloads/");
    system(command);
  }
  return;
}

int main() {
  int length, i = 0;
  char buffer[EVENT_BUF_LEN];
  char *old_name = NULL, *new_name = NULL;
  fp = fopen("log.txt", "wt");

  notify_fd = inotify_init();
  if(notify_fd < 0)
    perror("inotify_init");

  system("mkdir -p ./DummyHome/DummyDloads ./DummyHome/DummyDManager ./DummyHome/DummyTemp");

  nftw("./DummyHome/DummyDloads", callback, 40, 0);
  nftw("./DummyHome/DummyDManager", callback, 40, 0);
  nftw("./DummyHome/DummyTemp", callback, 40, 0);

  signal(SIGINT, main_sigint);
  while(true) {
    i = 0;
    memcpy(buffer, (char [EVENT_BUF_LEN]){'\0'}, EVENT_BUF_LEN);
    length = read(notify_fd, buffer, EVENT_BUF_LEN); 
    if(length < 0)
      perror("read");
    while(i < length) {
      struct inotify_event *event = (struct inotify_event *) &buffer[i];
      if(event->len) {
        if(event->mask & IN_CREATE) {
          if(event->mask & IN_ISDIR) {
            char temp_buffer[1024];
            strcpy(temp_buffer, wd[event->wd]);
            strcat(strcat(temp_buffer, "/"), event->name);
            add_watch(wd, notify_fd, temp_buffer);
            fprintf(fp, "[INFO] [CREATE DIR]\t'%s' in '%s'\n", event->name, wd[event->wd]);
            printf("[INFO] [CREATE DIR]\t'%s' in '%s'\n", event->name, wd[event->wd]);
          }
          else {
            fprintf(fp, "[INFO] [CREATE FILE]\t'%s' in '%s'\n", event->name, wd[event->wd]);
            printf("[INFO] [CREATE FILE]\t'%s' in '%s'\n", event->name, wd[event->wd]);
            remove_duplicate();
            copy_from_temp(event->name, wd[event->wd]);
          }
        }
        else if(event->mask & IN_DELETE) {
          if (event->mask & IN_ISDIR) {
            int idx;
            char temp[1024];
            fprintf(fp, "[INFO] [DELETE DIR]\t'%s' from '%s'\n", event->name, wd[event->wd]);
            printf("[INFO] [DELETE DIR]\t'%s' from '%s'\n", event->name, wd[event->wd]);
            strcpy(temp, wd[event->wd]);
            strcat(strcat(temp, "/"), event->name);
            for (idx = 0; idx < NO_OF_WATCH_DESCRIPTORS; ++idx)
              if(wd[idx] && !strcmp(temp, wd[idx]))
                break;
            remove_watch(wd, notify_fd, idx);
          }
          else {
            fprintf(fp, "[INFO] [DELETE FILE]\t'%s' from '%s'\n", event->name, wd[event->wd]);
            printf("[INFO] [DELETE FILE]\t'%s' from '%s'\n", event->name, wd[event->wd]);
          }
        }
        else if(event->mask & IN_OPEN || event->mask & IN_MODIFY) {
          if(!(event->mask & IN_ISDIR)) {
            fprintf(fp, "[INFO] [%s FILE]\t'%s' in '%s'\n", (event->mask & IN_OPEN) && (event->mask & IN_MODIFY) ? "OPEN & MODIFY" : event->mask & IN_OPEN ? "OPEN" : "MODIFY", event->name, wd[event->wd]);
            printf("[INFO] [%s FILE]\t'%s' in '%s'\n", (event->mask & IN_OPEN) && (event->mask & IN_MODIFY) ? "OPEN & MODIFY" : event->mask & IN_OPEN ? "OPEN" : "MODIFY", event->name, wd[event->wd]);
            if((event->mask & IN_MODIFY)) {
              remove_duplicate();
              copy_from_temp(event->name, wd[event->wd]);
            }
          }
        }
        else if(event->mask & IN_MOVED_FROM) {
          if (event->mask & IN_ISDIR) {
            fprintf(fp, "[INFO] [RENAME DIR]\t'%s' to ", event->name);
            printf("[INFO] [RENAME DIR]\t'%s' to ", event->name);
            old_name = (char *) calloc(strlen(event->name) + strlen(wd[event->wd]) + 1, 1);
            strcpy(old_name, wd[event->wd]);
            strcat(strcat(old_name, "/"), event->name);
          }
          else {
            fprintf(fp, "[INFO] [RENAME FILE]\t'%s' to ", event->name);
            printf("[INFO] [RENAME FILE]\t'%s' to ", event->name);
          }
        }
        else if(event->mask & IN_MOVED_TO) {
          if (event->mask & IN_ISDIR) {
            int idx;
            fprintf(fp, "'%s' in '%s'\n", event->name, wd[event->wd]);
            printf("'%s' in '%s'\n", event->name, wd[event->wd]);
            new_name = (char *) calloc(strlen(event->name) + strlen(wd[event->wd]) + 1, 1);
            strcpy(new_name, wd[event->wd]);
            strcat(strcat(new_name, "/"), event->name);            
            for (idx = 0; idx < NO_OF_WATCH_DESCRIPTORS; ++idx) {
              if(wd[idx] && strstr(wd[idx], old_name)) {
                char temp[1024];
                strcpy(temp, wd[idx] + strlen(old_name));
                free(wd[idx]);
                wd[idx] = (char *) calloc(strlen(new_name) + strlen(temp) + 1, 1);
                strcpy(wd[idx], new_name);
                strcat(wd[idx], temp);
              }
            }
            if(old_name) {
              free(old_name);
              old_name = NULL;
            }
            if(new_name) {
              free(new_name);
              new_name = NULL;
            }
          }
          else {
            fprintf(fp, "'%s' in '%s'\n", event->name, wd[event->wd]);
            printf("'%s' in '%s'\n", event->name, wd[event->wd]);
            remove_duplicate();
            copy_from_temp(event->name, wd[event->wd]);
          }
        }
      }
      i += EVENT_SIZE + event->len;
    }
  }

  for (i = 0; i < NO_OF_WATCH_DESCRIPTORS; ++i)
    if(wd[i])
      remove_watch(wd, notify_fd, i);

  close(notify_fd);
  if(fp)
    fclose(fp);
  return 0;
}